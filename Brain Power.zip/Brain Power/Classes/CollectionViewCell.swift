//
//  CollectionViewCell.swift
//  Brain Power
//
//  Created by Rebero Prince on 12/3/19.
//  Copyright © 2019 University of Rochester. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {

       
    @IBOutlet var animalImage: UIImageView!
}
